/*
OpenIO SDS integrity
Copyright (C) 2014 Worldine, original work as part of Redcurrant
Copyright (C) 2015 OpenIO, modified as part of OpenIO Software Defined Storage

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef G_LOG_DOMAIN
#define G_LOG_DOMAIN "integrity.lib.chunk_check"
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>

#include <metautils/lib/metautils.h>
#include <meta1v2/meta1_remote.h>
#include <meta2v2/meta2_remote.h>
#include <meta2v2/meta2v2_remote.h>
#include <meta2v2/generic.h>
#include <meta2v2/autogen.h>
#include <client/c/lib/gs_internals.h>
#include <rawx-lib/src/rawx.h>

#include "check.h"
#include "content_check.h"
#include "chunk_check.h"
#include "broken_event.h"

/**
 * Compute the MD5 hash of a chunk file
 *
 * @param chunk_path the full path to the chunk file
 * @param chunk_hash the chunk_hash_t to fill with the computed hash
 * @param error
 *
 * @return TRUE or FALSE if an error occured (error is set)
 */
static gboolean
_compute_chunk_md5_hash(const gchar * chunk_path, chunk_hash_t chunk_hash, GError ** error)
{
	int fd;
	size_t len;
	ssize_t size_read;
	guint8 buffer[4096];
	GChecksum *md5_sum = NULL;

	memset(buffer, 0, sizeof(buffer));

	fd = open(chunk_path, O_RDONLY);
	if (fd == -1) {
		GSETERROR(error, "Failed to open chunk file [%s] for reading : %s", chunk_path, strerror(errno));
		return FALSE;
	}

	md5_sum = g_checksum_new(G_CHECKSUM_MD5);
	if (md5_sum == NULL) {
		GSETERROR(error, "GChecksum allocation failure");
		metautils_pclose(&fd);
		return FALSE;
	}

	while (0 < (size_read = read(fd, buffer, sizeof(buffer)))) {
		g_checksum_update(md5_sum, buffer, size_read);
		memset(buffer, 0, sizeof(buffer));
	}

	metautils_pclose(&fd);
	len = sizeof(chunk_hash_t);
	g_checksum_get_digest(md5_sum, chunk_hash, &len);
	g_checksum_free(md5_sum);

	if (size_read == -1) {
		GSETERROR(error, "Failed while reading chunk file [%s] : %s", chunk_path, strerror(errno));
		memset(chunk_hash, 0, sizeof(chunk_hash_t));
		return FALSE;
	}

	if (len != sizeof(chunk_hash_t)) {
		GSETERROR(error, "Chunk file content computed hash hash wrong size : %d instead of %d", len,
		    sizeof(chunk_hash_t));
		memset(chunk_hash, 0, sizeof(chunk_hash_t));
		return FALSE;
	}

	return TRUE;
}

gboolean
check_chunk_integrity(const char *chunk_path, const struct chunk_textinfo_s * text_chunk, GSList ** mismatch,
    GError ** error)
{
	GError *local_error = NULL;
	chunk_hash_t chunk_file_hash, chunk_attr_hash;
	gint64 chunk_attr_size;

	CHECK_ARG_POINTER(chunk_path, error);
	CHECK_ARG_POINTER(text_chunk, error);
	CHECK_ARG_VALID_FILE(chunk_path, error);

#define ADD_BRK_EL_TXT(L, P, R, V) \
do {\
	struct broken_element_s* brk_el; \
	brk_el = broken_element_alloc2(text_chunk->container_id, text_chunk->path, text_chunk->id, L, P, R, V); \
	if (brk_el != NULL) \
		*mismatch = g_slist_prepend(*mismatch, brk_el); \
	else { \
		GSETERROR(error, "Memory allocation failure"); \
		goto error; \
	} \
} while(0)

	/* See if we have a chunk_hash in attr */
	if (text_chunk->hash != NULL) {

		/* Compute chunk hash from file */
		if (!_compute_chunk_md5_hash(chunk_path, chunk_file_hash, error)) {
			GSETERROR(error, "Failed to compute MD5 hash of chunk file [%s]", chunk_path);
			goto error;
		}

		/* Convert attr chunk hash to bin */
		if (!hex2bin(text_chunk->hash, chunk_attr_hash, sizeof(chunk_hash_t), &local_error)) {
			WARN("Failed to convert chunk hash from hex [%s] to bin format : %s", text_chunk->hash,
			    local_error->message);
			g_clear_error(&local_error);
		}
		else if (0 != memcmp(chunk_file_hash, chunk_attr_hash, sizeof(chunk_hash_t)))
			ADD_BRK_EL_TXT(L_CHUNK, P_CHUNK_HASH, R_MISMATCH, g_memdup(chunk_attr_hash,
				sizeof(chunk_hash_t)));
	}

	/* See if we have a chunk size in attr */
	if (text_chunk->size != NULL) {
		struct stat file_stat;

		chunk_attr_size = g_ascii_strtoll(text_chunk->size, NULL, 10);

		/* Read chunk file size */
		memset(&file_stat, 0, sizeof(struct stat));
		if (-1 == stat(chunk_path, &file_stat)) {
			GSETERROR(error, "Failed to stat chunk file [%s] : %s", chunk_path, strerror(errno));
			goto error;
		}

		/* Compare chunk size */
		if (file_stat.st_size != chunk_attr_size){
			NOTICE("Chunk size mismatch, starting new broken event");
			ADD_BRK_EL_TXT(L_CHUNK, P_CHUNK_SIZE, R_MISMATCH, g_memdup(&chunk_attr_size,
				sizeof(chunk_attr_size)));
		}
	}
	else {
		NOTICE("text_chunk size =NULL!...\n");
		ADD_BRK_EL_TXT(L_CHUNK, P_CHUNK_SIZE, R_MISMATCH, g_memdup(&chunk_attr_size, sizeof(chunk_attr_size)));
	
	}
	return TRUE;

      error:
	if (*mismatch != NULL) {
		g_slist_foreach(*mismatch, broken_element_gfree, NULL);
		g_slist_free(*mismatch);
		*mismatch = NULL;
	}

	return FALSE;
}

static gint
_chunk_position_comparator(gconstpointer _chunk, gconstpointer _str_position) {
	guint32 position = g_ascii_strtoull((const gchar*)_str_position, NULL, 10);
	const struct meta2_raw_chunk_s *chunk = _chunk;
	return chunk->position - position;
}

static gint
_chunk_id_comparator(gconstpointer _chunk, gconstpointer _str_id) {
	const gchar *str_id = _str_id;
	const struct meta2_raw_chunk_s *chunk = _chunk;
	gchar id[STRLEN_CHUNKID];
	buffer2str(chunk->id.id, sizeof(chunk->id.id), id, sizeof(id));
	return g_strcmp0(id, str_id);
}

static gint
_chunk_hash_comparator(gconstpointer _chunk, gconstpointer _str_hash) {
	const gchar *str_hash = _str_hash;
	const struct meta2_raw_chunk_s *chunk = _chunk;
	gchar hash_from_chunk[STRLEN_CHUNKHASH];
	buffer2str(chunk->hash, sizeof(chunk->hash), hash_from_chunk, sizeof(hash_from_chunk));
	return g_strcmp0(hash_from_chunk, str_hash);
}

static struct meta2_raw_chunk_s *
_get_chunk(GSList *raw_chunks, const chunk_textinfo_t *ci)
{
	GSList *found_element = NULL;

#define FIND_CHUNK(attr, func) \
		found_element = g_slist_find_custom(raw_chunks, attr, func); \
		if (found_element) \
			return found_element->data;

	FIND_CHUNK(ci->id, _chunk_id_comparator);
	FIND_CHUNK(ci->hash, _chunk_hash_comparator);
	FIND_CHUNK(ci->position, _chunk_position_comparator);

#undef FIND_CHUNK

	return NULL;
}

static gboolean
check_chunk_referencing_full(const struct content_textinfo_s * content_from_chunk,
    const struct chunk_textinfo_s * chunk_from_chunk, const struct meta2_raw_content_s * content_from_meta2,
    struct meta2_raw_chunk_s *raw_chunk, GSList ** broken, GError ** error)
{
	struct meta2_raw_chunk_s *chunk_from_meta2 = NULL;
	GError *local_error = NULL;

	CHECK_ARG_POINTER(content_from_chunk, error);
	CHECK_ARG_POINTER(chunk_from_chunk, error);
	CHECK_ARG_POINTER(content_from_meta2, error);
	CHECK_ARG_POINTER(content_from_meta2->raw_chunks, error);

#define ADD_BRK_EL_BIN(L, P, R, V) \
do {\
	struct broken_element_s* brk_el; \
	brk_el = broken_element_alloc(content_from_meta2->container_id, content_from_meta2->path, chunk_from_meta2->id.id, L, P, R, V); \
	if (brk_el != NULL) \
		*broken = g_slist_prepend(*broken, brk_el); \
	else { \
		GSETERROR(error, "Memory allocation failure"); \
		goto error; \
	} \
} while(0)

	if (g_slist_length(content_from_meta2->raw_chunks) == 0) {
		GSETERROR(error, "List of raw_chunk in content from META2 is emty");
		return FALSE;
	}

	if (raw_chunk) {
		chunk_from_meta2 = raw_chunk;
	} else {
		chunk_from_meta2 = _get_chunk(content_from_meta2->raw_chunks,
				chunk_from_chunk);
		if (chunk_from_meta2 ==NULL)
			return FALSE;
	}

	gboolean check_chunk_hash_same  = FALSE;
	gboolean check_chunk_id_notsame = FALSE;
	gboolean is_referenced = TRUE;

	/* Check chunk hash */
	if (chunk_from_chunk->hash == NULL && !data_is_zeroed(chunk_from_meta2->hash, sizeof(chunk_hash_t))) {
		ADD_BRK_EL_BIN(L_CHUNK, P_CHUNK_HASH, R_MISSING, g_memdup(chunk_from_meta2->hash,
			sizeof(chunk_hash_t)));
	}
	else if (data_is_zeroed(chunk_from_meta2->hash, sizeof(chunk_hash_t)) && chunk_from_chunk->hash != NULL) {
		ADD_BRK_EL_BIN(L_META2, P_CHUNK_HASH, R_MISSING, NULL);
	}
	else {
		chunk_hash_t hash;

		if (!hex2bin(chunk_from_chunk->hash, hash, sizeof(chunk_hash_t), &local_error)) {
			WARN("Failed to convert chunk_hash from hex [%s] to bin : %s", chunk_from_chunk->hash,
			    local_error->message);
			g_clear_error(&local_error);
			ADD_BRK_EL_BIN(L_CHUNK, P_CHUNK_HASH, R_FORMAT, g_memdup(chunk_from_meta2->hash,
				sizeof(chunk_hash_t)));
		}
		else if (0 != memcmp(chunk_from_meta2->hash, hash, sizeof(chunk_hash_t)))
			ADD_BRK_EL_BIN(L_ALL, P_CHUNK_HASH, R_MISMATCH, g_memdup(chunk_from_meta2->hash,
				sizeof(chunk_hash_t)));
		else check_chunk_hash_same = TRUE;
		
	}

	/* Check chunk id */
	if (chunk_from_chunk->id == NULL && !data_is_zeroed(chunk_from_meta2->id.id, sizeof(hash_sha256_t))) {
		ADD_BRK_EL_BIN(L_CHUNK, P_CHUNK_ID, R_MISSING, g_memdup(chunk_from_meta2->id.id,
			sizeof(hash_sha256_t)));
	}
	else if (data_is_zeroed(chunk_from_meta2->id.id, sizeof(hash_sha256_t)) && chunk_from_chunk->id != NULL) {
		ADD_BRK_EL_BIN(L_META2, P_CHUNK_ID, R_MISSING, NULL);
	}
	else {
		hash_sha256_t id;

		if (!hex2bin(chunk_from_chunk->id, id, sizeof(hash_sha256_t), &local_error)) {
			WARN("Failed to convert chunk_id from hex [%s] to bin : %s", chunk_from_chunk->id,
			    local_error->message);
			g_clear_error(&local_error);
			ADD_BRK_EL_BIN(L_CHUNK, P_CHUNK_ID, R_FORMAT, g_memdup(chunk_from_meta2->id.id,
				sizeof(hash_sha256_t)));
		}
		else if (0 != memcmp(chunk_from_meta2->id.id, id, sizeof(hash_sha256_t))) {			
			check_chunk_id_notsame = TRUE;
			// ADD_BRK_EL_BIN(L_ALL, P_CHUNK_ID, R_MISMATCH, g_memdup(chunk_from_meta2->id.id,
            //         sizeof(hash_sha256_t)));
			
		}
	}

	/* Check chunk size */
	if (chunk_from_chunk->size == NULL) {
		ADD_BRK_EL_BIN(L_CHUNK, P_CHUNK_SIZE, R_MISSING, g_memdup(&(chunk_from_meta2->size),
			sizeof(chunk_from_meta2->size)));
	}
	else {
		gint64 size = g_ascii_strtoll(chunk_from_chunk->size, NULL, 10);

		if (size != chunk_from_meta2->size)
			ADD_BRK_EL_BIN(L_ALL, P_CHUNK_SIZE, R_MISMATCH, g_memdup(&(chunk_from_meta2->size),
				sizeof(chunk_from_meta2->size)));
	}

	/* Check chunk position */
	if (chunk_from_chunk->position == NULL) {
		ADD_BRK_EL_BIN(L_CHUNK, P_CHUNK_POS, R_MISSING, g_memdup(&(chunk_from_meta2->position),
			sizeof(chunk_from_meta2->position)));
	}
	else {
		guint32 position = atoi(chunk_from_chunk->position);

		if (position != chunk_from_meta2->position)
			ADD_BRK_EL_BIN(L_ALL, P_CHUNK_POS, R_MISMATCH, g_memdup(&(chunk_from_meta2->position),
				sizeof(chunk_from_meta2->position)));
	}

	/* Check content name */
	if (content_from_chunk->path == NULL
	    && !data_is_zeroed(content_from_meta2->path, sizeof(content_from_meta2->path))) {
		NOTICE("chunk_check: path null..\n");
		ADD_BRK_EL_BIN(L_CHUNK, P_CONTENT_NAME, R_MISSING, g_strdup(content_from_meta2->path));
	}
	else if (data_is_zeroed(content_from_meta2->path, sizeof(content_from_meta2->path))
	    && content_from_chunk->path != NULL) {
		ADD_BRK_EL_BIN(L_META2, P_CONTENT_NAME, R_MISSING, g_strdup(content_from_chunk->path));
	}
	else if (strncmp(content_from_chunk->path, content_from_meta2->path, LIMIT_LENGTH_CONTENTPATH)) {
		ADD_BRK_EL_BIN(L_ALL, P_CONTENT_NAME, R_MISMATCH, g_strdup(content_from_meta2->path));
	}

	/* Check content system metadata */
	if (content_from_chunk->system_metadata == NULL && content_from_meta2->system_metadata != NULL) {
		ADD_BRK_EL_BIN(L_CHUNK, P_CONTENT_SYSMETADATA, R_MISSING,
		    g_memdup(content_from_meta2->system_metadata->data, content_from_meta2->system_metadata->len));
	}
	else if ((content_from_meta2->system_metadata == NULL || content_from_meta2->system_metadata->len == 0)
	    && content_from_chunk->system_metadata != NULL) {
		ADD_BRK_EL_BIN(L_META2, P_CONTENT_SYSMETADATA, R_MISSING, g_strdup(content_from_chunk->system_metadata));
	}
	else {
		gchar metadata[content_from_meta2->system_metadata->len + 1];

		memset(metadata, '\0', sizeof(metadata));
		memcpy(metadata, content_from_meta2->system_metadata->data, sizeof(metadata) - 1);

		if (!metadata_equal(content_from_chunk->system_metadata, metadata, NULL))
			ADD_BRK_EL_BIN(L_ALL, P_CONTENT_SYSMETADATA, R_MISMATCH,
			    g_memdup(content_from_meta2->system_metadata->data,
				content_from_meta2->system_metadata->len));
	}

	/* Check properties on chunk with position 0 */
	if (chunk_from_chunk->position != NULL && 0 == atoi(chunk_from_chunk->position)) {
		/* Check content nb chunk */
		if (content_from_chunk->chunk_nb == NULL) {
			ADD_BRK_EL_BIN(L_CHUNK, P_CONTENT_CHUNK_NB, R_MISSING,
			    g_memdup(&(content_from_meta2->nb_chunks), sizeof(content_from_meta2->nb_chunks)));
		}
		else {
			guint32 nb_chunk = atoi(content_from_chunk->chunk_nb);

			if (nb_chunk != content_from_meta2->nb_chunks)
				ADD_BRK_EL_BIN(L_ALL, P_CONTENT_CHUNK_NB, R_MISMATCH,
				    g_memdup(&(content_from_meta2->nb_chunks), sizeof(content_from_meta2->nb_chunks)));
		}

		/* Check content size */
		if (content_from_chunk->size == NULL) {
			ADD_BRK_EL_BIN(L_CHUNK, P_CONTENT_SIZE, R_MISSING, g_memdup(&(content_from_meta2->size),
				sizeof(content_from_meta2->size)));
		}
		else {
			gint64 size = g_ascii_strtoll(content_from_chunk->size, NULL, 10);

			if (size != content_from_meta2->size)
				ADD_BRK_EL_BIN(L_ALL, P_CONTENT_SIZE, R_MISMATCH, g_memdup(&(content_from_meta2->size),
					sizeof(content_from_meta2->size)));
		}
	}

	//--------------------
	// for differenciation between dupplicated chunk / other content chunk / broken chunk
	if ((*broken != NULL)&&(g_slist_length(*broken)> 0)) {
		// error --> add the chunk_id error if there is
		if (check_chunk_id_notsame == TRUE)
			 ADD_BRK_EL_BIN(L_ALL, P_CHUNK_ID, R_MISMATCH, g_memdup(chunk_from_meta2->id.id,
                     sizeof(hash_sha256_t)));

	} else if (check_chunk_hash_same == FALSE) {
		// no error / same id / NOT smae hash --> chunk not for this content
        if (check_chunk_id_notsame == TRUE)
             ADD_BRK_EL_BIN(L_ALL, P_CHUNK_ID, R_MISMATCH, g_memdup(chunk_from_meta2->id.id,
                      sizeof(hash_sha256_t)));		
				
	} else if (check_chunk_id_notsame == TRUE) {
		// no error / not same id / same hash  --> chunk not referenced / no other error
		is_referenced = FALSE;
	}

	return is_referenced;

error:
	if (*broken != NULL) {
		g_slist_foreach(*broken, broken_element_gfree, NULL);
		g_slist_free(*broken);
		*broken = NULL;
	}

	return FALSE;
}

gboolean
check_chunk_referencing(const struct content_textinfo_s * content_from_chunk,
    const struct chunk_textinfo_s * chunk_from_chunk, const struct meta2_raw_content_s * content_from_meta2,
    GSList ** broken, GError ** error)
{
	return check_chunk_referencing_full(content_from_chunk, chunk_from_chunk,
			content_from_meta2, NULL, broken, error);
}

gboolean
check_chunk_info(struct chunk_textinfo_s *chunk, GError **p_error)
{
	CHECK_INFO(chunk->path,		p_error, "Missing mandatory content path");
	CHECK_INFO(chunk->id,		p_error, "Missing mandatory chunk ID");
	CHECK_INFO(chunk->size,		p_error, "Missing mandatory chunk size");
	CHECK_INFO(chunk->hash,		p_error, "Missing mandatory chunk hash");
	CHECK_INFO(chunk->position,	p_error, "Missing mandatory chunk position");
	return TRUE;
}

static void
_set_or_free_error(GError *err, GError **p_err)
{
	if (err) {
		if (p_err) {
			*p_err = err;
		} else {
			GRID_ERROR("[%s]", err->message);
			g_error_free(err);
		}
	}
}

static gboolean
_create_container(struct meta2_ctx_s *ctx, container_id_t *p_cid, GError **p_err)
{
	addr_info_t *p_m1_addr = NULL;
	gboolean ret = FALSE;

	p_m1_addr = gs_resolve_meta1v2 (ctx->hc /*container->info.gs*/,
			*p_cid,  ctx->loc->container_name, 0, NULL, p_err);
	if (!p_m1_addr) {
		GSETERROR(p_err, "META1 resolution error for [%s]", ctx->loc->container_name);
		goto clean_up;
	}

	struct hc_url_s *u = hc_url_empty ();
	hc_url_set (u, HCURL_NS, ctx->ns);
	hc_url_set (u, HCURL_USER, ctx->loc->container_name);
	gboolean rc = meta1_remote_create_container_v2(p_m1_addr, p_err, u);
	hc_url_clean (u);

	if (!rc && p_err && *p_err)
		goto clean_up;

	ret = TRUE;

clean_up:
	if (p_m1_addr)
		addr_info_clean(p_m1_addr);

	return ret;
}

static gint64
_extract_date_from_sysmd(const guint8 *mdsys, gsize mdsys_len)
{
	GError *err = NULL;
	GHashTable *unpacked = metadata_unpack_buffer(mdsys, mdsys_len, &err);
	GHashTableIter iter;
	gpointer k, v;
	gint64 md_date = -1;

	if (!err) {
		g_hash_table_iter_init(&iter, unpacked);
		while (g_hash_table_iter_next(&iter, &k, &v)) {
			if (g_str_equal(k, "creation-date")) {
				md_date = g_ascii_strtoll(v, NULL, 10);
				break;
			}
		}
	} else {
		GRID_DEBUG("Cannot extract date from system metadata: %s",
				err->message ? err->message : "<no details>");
		g_error_free(err);
	}

	g_hash_table_destroy(unpacked);
	return md_date;
}

static gboolean
_ensure_container_created_in_m2(struct meta2_ctx_s *ctx,
		gchar *stgpol, check_result_t *cres, GError **p_err)
{
	addr_info_t m2;
	gboolean ret = FALSE;
	GError *local_error = NULL;

	GRID_DEBUG("m2addr_str=%s", ctx->loc->m2_url[0]);

	// suppose container does not exist: create it
	grid_string_to_addrinfo(ctx->loc->m2_url[0], NULL, &m2);
	do {
		struct hc_url_s *url = hc_url_empty ();
		hc_url_set (url, HCURL_NS, ctx->ns);
		hc_url_set (url, HCURL_USER, ctx->loc->container_name);
		ret = meta2_remote_container_create_v3 (&m2, META2_TIMEOUT, &local_error, url, stgpol);
		hc_url_clean (url);
	} while (0);

	if (ret && !local_error) {
		check_result_append_msg(cres, "Created container [%s]",
				ctx->loc->container_hexid);
	} else if (local_error) {
		if (local_error->code == CODE_CONTAINER_EXISTS) {
			g_clear_error(&local_error);
			GRID_DEBUG("Container [%s/%s] already exist on meta2 [%s]",
					ctx->ns, ctx->loc->container_name,
					ctx->loc->m2_url[0]);
			ret = TRUE;
		} else {
			GRID_DEBUG("Failed to create container [%s/%s] (%s).",
					ctx->ns, ctx->loc->container_name, local_error->message);
			_set_or_free_error(local_error, p_err);
		}
	}

	return ret;
}

static gboolean
_ensure_container_created(struct meta2_ctx_s *ctx, check_info_t *check_info,
		check_result_t *cres, GError **p_err)
{
	gboolean ret = FALSE;
	GError *local_error = NULL;
	struct content_textinfo_s *ct_info = check_info->ct_info;
	gchar *hexid = ct_info->container_id;
	container_id_t cid;

	GRID_DEBUG("Check/Create container with...storage_policy=%s, version=%s, container_id=%s, container_name=%s/%s,",
			ct_info->storage_policy, ct_info->version,
			hexid, ctx->ns, ctx->loc->container_name);

	if (!container_id_hex2bin(hexid, strlen(hexid), &cid, &local_error))
		goto clean_up;

	if (ctx->loc->m2_url == NULL) {
		if (!_create_container(ctx, &cid, p_err))
			goto clean_up;

		// log message
		check_result_append_msg(cres, "Created container [%s]",
				ct_info->container_id);
	} else {
		if (!_ensure_container_created_in_m2(ctx, ct_info->storage_policy, cres, p_err))
			goto clean_up;
	}

	ret = TRUE;

clean_up:
	return ret;
}

gchar *
compute_file_md5(const gchar *filepath)
{
	FILE *fp;
	guint8 buf[8096];
	gint read_bytes;
	gchar *strmd5 = NULL;
	GChecksum *checksum = NULL;

	errno = 0;
	if (NULL != (fp = fopen(filepath, "rb"))) {
		checksum = g_checksum_new(G_CHECKSUM_MD5);
		while ((read_bytes = fread(buf, 1, sizeof(buf), fp)) > 0)
			g_checksum_update(checksum, buf, read_bytes);
		strmd5 = g_strdup(g_checksum_get_string(checksum));
		fclose(fp);
		g_checksum_free(checksum);
	} else {
		GRID_DEBUG("Could not open file [%s] (%s)",
				filepath, strerror(errno));
	}
	return strmd5;
}

static gboolean
_check_chunk_md5(check_info_t *check_info)
{
	gboolean ret;
	gchar *filemd5 = compute_file_md5(check_info->source_path);
	ret = (0 == g_ascii_strncasecmp(filemd5, check_info->ck_info->hash, STRLEN_CHUNKHASH));
	g_free(filemd5);
	return ret;
}

static gboolean
_fill_raw_content_with_info(struct meta2_raw_content_s *rc,
		check_info_t *check_info, GError **p_err)
{
	struct content_textinfo_s *ci = check_info->ct_info;

	if (!rc)
		return FALSE;

	// CONTAINER ID
	if (ci->container_id)
		hex2bin(ci->container_id, rc->container_id,
				sizeof(rc->container_id), p_err);

	// NB CHUNKS
	if (ci->chunk_nb)
		rc->nb_chunks = g_ascii_strtoull(ci->chunk_nb, NULL, 10);

	// CONTENT PATH
	if (ci->path)
		g_strlcpy(rc->path, ci->path, sizeof(rc->path));

	// SIZE
	if (ci->size)
		rc->size = g_ascii_strtoll(ci->size, NULL, 10);

	// STORAGE POLICY
	rc->storage_policy = g_strdup(ci->storage_policy);

	// SYSTEM METADATA
	if (ci->system_metadata) {
		if (rc->metadata)
			g_byte_array_free(rc->metadata, TRUE);
		rc->system_metadata = g_byte_array_append(g_byte_array_new(),
				(guint8*)ci->system_metadata, strlen(ci->system_metadata));
	}

	// VERSION
	if (ci->version)
		rc->version = g_ascii_strtoll(ci->version, NULL, 10);

	return TRUE;
}
static gboolean
_fill_raw_chunk_with_info(struct meta2_raw_chunk_s *rc,
		check_info_t *check_info, GError **p_err)
{
	GError *err = NULL;

	if (!rc)
		return FALSE;

	err = generate_raw_chunk(check_info, rc);
	if (err) {
		_set_or_free_error(err, p_err);
		return FALSE;
	}

	memset(rc->id.vol, 0, sizeof(rc->id.vol));
	memcpy(rc->id.vol, check_info->rawx_vol, sizeof(rc->id.vol));
	/* make sure volume does not end with '/' */
	if (rc->id.vol[strlen(rc->id.vol) - 1] == '/')
		rc->id.vol[strlen(rc->id.vol) - 1] = '\0';
	grid_string_to_addrinfo(check_info->rawx_str_addr, NULL, &(rc->id.addr));

	return TRUE;
}

static gboolean
_add_missing_chunk(struct meta2_ctx_s *ctx, check_info_t *check_info,
		check_result_t *cres, GError **p_err)
{
	const gboolean is_dryrun = check_option_get_bool(check_info->options,
			CHECK_OPTION_DRYRUN);
	gboolean ret = FALSE;

	if (!ctx->content) {
		GRID_DEBUG("Cannot add chunk [%s]: no content.", check_info->ck_info->id);
		return FALSE;
	}

	meta2_raw_chunk_t *newchunk = g_malloc0(sizeof(meta2_raw_chunk_t));
	if (!_fill_raw_chunk_with_info(newchunk, check_info, p_err)) {
		GRID_DEBUG("Error filling new chunk for content [%s]",
				check_info->ct_info->path);
		g_free(newchunk);
		goto clean_up;
	}
	ctx->content->raw_chunks = g_slist_prepend(ctx->content->raw_chunks, newchunk);

	if (is_dryrun) {
		check_result_append_msg(cres, "dryrun prevented chunk update in [%s/%s]",
				check_info->ct_info->container_id,
				check_info->ct_info->path);
	} else {
		struct hc_url_s *url = hc_url_empty ();
		hc_url_set (url, HCURL_NS, check_info->ns_name);
		hc_url_set_id (url, ctx->content->container_id);
		hc_url_set (url, HCURL_PATH, ctx->content->path);
 		gboolean rc = meta2raw_remote_update_content(ctx->m2_cnx, p_err, url, ctx->content, TRUE);
		hc_url_clean (url);

		if (!rc) {
			GRID_DEBUG("Error updating chunk [%s] in content [%s]",
					check_info->ck_info->id, check_info->ct_info->path);
			goto clean_up;
		}
		check_result_append_msg(cres, "Chunk referenced in [%s/%s]",
				check_info->ct_info->container_id,
				check_info->ct_info->path);
	}

	ret = TRUE;

clean_up:
	return ret;
}

static gboolean
_find_content_from_chunkid(struct meta2_ctx_s *ctx, check_info_t *check_info,
		GError **p_err)
{
	gboolean ret = FALSE;
	GSList *chunk_ids = NULL;
	struct hc_url_s *url = NULL;
	gchar m2addr_str[STRLEN_ADDRINFO];
	GError *local_error = NULL;
	struct content_textinfo_s *content_info = check_info->ct_info;
	gchar *old_content_path = content_info->path;

	// init container url
	url = hc_url_empty();
	hc_url_set(url, HCURL_NS, check_info->ns_name);
	hc_url_set(url, HCURL_HEXID, content_info->container_id);

	// content path will be reset
	content_info->path = NULL;

	// locate content and all its chunks
	if (ctx->m2_cnx) {
		addr_info_to_string(&(ctx->m2_cnx->addr), m2addr_str, sizeof(m2addr_str));
		local_error = find_storage_policy_and_friend_chunks_full(
				m2addr_str, url, check_info, &chunk_ids, &(ctx->content));
	}

	// if content not found, return FALSE
	if (local_error || !content_info->path) {
		GRID_DEBUG("content [%s] not found.", old_content_path);
		goto clean_up;
	} else {
		GRID_DEBUG("Content found using chunk id [%s].",
				check_info->ck_info->id);
	}

	ret = TRUE;

clean_up:
	// if path was updated, free the old value, otherwise set it back
	if (content_info->path)
		g_free(old_content_path);
	else
		content_info->path = old_content_path;
	hc_url_clean(url);
	g_slist_free_full(chunk_ids, g_free);
	_set_or_free_error(local_error, p_err);

	return ret;
}

static GError*
_content_fill(struct meta2_ctx_s *ctx, check_info_t *check_info)
{
	GError* local_error = NULL;
	meta2_raw_content_clean(ctx->content);
	ctx->content = g_malloc0(sizeof(meta2_raw_content_t));
	if (!_fill_raw_content_with_info(ctx->content, check_info, &local_error))
		GRID_DEBUG("Error filling new content [%s]", check_info->ct_info->path);
	return local_error;
}

static GError*
_content_remove(struct meta2_ctx_s *ctx, check_info_t *check_info,
		check_result_t *cres)
{
	const gboolean is_dryrun = check_option_get_bool(check_info->options,
			CHECK_OPTION_DRYRUN);
	GError *local_error = NULL;
	gchar*      hexid = check_info->ct_info->container_id;
	container_id_t cid;
	gchar *content_path = check_info->ct_info->path;

	if (is_dryrun) {
		check_result_append_msg(cres, "dryrun prevented from removing "
				"content [%s] in container [%s]", content_path, hexid);
		return NULL;
	}

	if (!container_id_hex2bin(hexid, strlen(hexid), &cid, &local_error))
		return local_error;

	//remove content
	struct hc_url_s *url = hc_url_empty ();
	hc_url_set (url, HCURL_NS, ctx->ns);
	hc_url_set (url, HCURL_USER, ctx->loc->container_name);
	hc_url_set (url, HCURL_PATH, ctx->content->path);

	local_error = m2v2_remote_execute_DEL (ctx->loc->m2_url[0], url);
	if (local_error)
		GSETERROR(&local_error, "Remove error: ");
	hc_url_clean (url);
	return local_error;
}

static gboolean
_check_chunk_pending(check_info_t *check_info, check_result_t *cres)
{
	const gboolean is_dryrun = check_option_get_bool(check_info->options,
			CHECK_OPTION_DRYRUN);

	if (_check_chunk_md5(check_info)) {
		if (is_dryrun) {
			check_result_append_msg(cres, "dryrun prevented from removing extension [%s]",
					check_info->source_path);
		} else {
			if (remove_file_extension(check_info->source_path))
				check_result_append_msg(cres, "Removed extension of filename [%s]",
						check_info->source_path);
			else
				check_result_append_msg(cres, "Could not rename file [%s]",
						check_info->source_path);
		}
		return TRUE;
	}

	// wrong md5, move .pending chunk to trash
	if (trash_chunk(check_info, cres))
		check_result_append_msg(cres, "(corrupted .pending)");

	return FALSE;
}

gboolean
replace_chunk(struct meta2_ctx_s *ctx, struct meta2_raw_chunk_s *rc,
		check_info_t *check_info, GError **p_err)
{
	struct hc_url_s *url = hc_url_empty ();
	hc_url_set (url, HCURL_NS, ctx->ns);
	hc_url_set (url, HCURL_USER, ctx->loc->container_name);
	hc_url_set (url, HCURL_PATH, ctx->content->path);

	if (!meta2raw_remote_delete_chunks(ctx->m2_cnx, p_err, url, ctx->content)) {
		GRID_DEBUG("Error deleting chunks in content [%s]",
				check_info->ct_info->path);
		hc_url_clean (url);
		return FALSE;
	}
	if (!_fill_raw_chunk_with_info(rc, check_info, p_err)) {
		GRID_DEBUG("Error updating raw chunks in content [%s]",
				check_info->ct_info->path);
		hc_url_clean (url);
		return FALSE;
	}
	if (!meta2raw_remote_update_content(ctx->m2_cnx, p_err, url,
			ctx->content, TRUE)) {
		GRID_DEBUG("Error fixing chunk [%s] in content [%s]",
				check_info->ck_info->id, check_info->ct_info->path);
		hc_url_clean (url);
		return FALSE;
	}

	hc_url_clean (url);
	return TRUE;
}

static void
_append_brk_el_to_result(struct content_textinfo_s *content_info,
		GSList *broken_elements, check_result_t *cres)
{
	static const gchar* const property_names[] = {
			"containerid",
			"contentname",
			"contentsize",
			"contentchunknb",
			"contentmetadata",
			"contentsystemmetadata",
			"chunkid",
			"chunksize",
			"chunkhash",
			"chunkposition",
			"chunkmetadata"
	};

	void _append_brk_el(gpointer _brk_el, gpointer _udata)
	{
		struct broken_element_s *brk_el = _brk_el;
		const gint prop_index = brk_el->property - 1;
		const gchar *reason = reason_to_str[brk_el->reason];
		const gchar *location = loc_to_str[brk_el->location];
		(void) _udata;
		if (prop_index >= 0)
			check_result_append_msg(cres, "%s (%s on %s)",
					property_names[prop_index], reason, location);
		else
			check_result_append_msg(cres, "unknown (index %i) ", prop_index);
	}

	check_result_append_msg(cres, "[%s/%s] broken elements:[",
			content_info->path, content_info->container_id);
	g_slist_foreach(broken_elements, _append_brk_el, NULL);
	check_result_append_msg(cres, "]");
}

static gboolean
_rename_file(const gchar *src_file, const gchar *dst_file)
{
	errno = 0;
	if (-1 == rename(src_file, dst_file)) {
		GRID_ERROR("Could not move file from [%s] to [%s] (%s).",
				src_file, dst_file, strerror(errno));
		return FALSE;
	}
	return TRUE;
}

static gboolean
_ensure_dir_created(const gchar *dir_path)
{
	if (!g_file_test(dir_path, G_FILE_TEST_IS_DIR)) {
		errno = 0;
		// create directory with permissions 775
		if (-1 == mkdir(dir_path, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
			GRID_ERROR("Could not create directory [%s] (%s).",
					dir_path, strerror(errno));
			return FALSE;
		}
		GRID_DEBUG("Created directory [%s]", dir_path);
	}

	return TRUE;
}

static gboolean
_move_file_to_dir(const gchar *src_file, const gchar *dst_dir)
{
	gboolean ret;
	GString *dst_file = NULL;

	if (!_ensure_dir_created(dst_dir))
		return FALSE;

	// append source file name to destination path, including '/'
	dst_file = g_string_new(dst_dir);
	g_string_append(dst_file, strrchr(src_file, G_DIR_SEPARATOR));
	ret = _rename_file(src_file, dst_file->str);
	g_string_free(dst_file, TRUE);
	return ret;
}

gboolean
remove_file_extension(const gchar *path)
{
	gboolean ret;
	GString *dst_file = g_string_new(path);
	const gsize dst_len = strrchr(path, '.') - path;

	g_string_truncate(dst_file, dst_len);
	ret = _rename_file(path, dst_file->str);
	g_string_free(dst_file, TRUE);

	return ret;
}

gboolean
trash_chunk(check_info_t *check_info, check_result_t *cres)
{
	gboolean ret;
	GString *dst_dir = g_string_new(check_info->rawx_vol);
	GString *src_file = g_string_new(check_info->source_path);
	const gboolean is_dryrun = check_option_get_bool(check_info->options,
			CHECK_OPTION_DRYRUN);

	// if rawx volume does not end with '/', append it
	if (dst_dir->str[dst_dir->len - 1] != G_DIR_SEPARATOR)
		g_string_append_c(dst_dir, G_DIR_SEPARATOR);

	g_string_append(dst_dir, RAWX_LOSTFOUND_FOLDER);
	if (is_dryrun) {
		ret = TRUE;
		check_result_append_msg(cres, "dryrun prevented from moving chunk to "
				RAWX_LOSTFOUND_FOLDER);
	} else {
		ret = _move_file_to_dir(src_file->str, dst_dir->str);
		if (ret)
			check_result_append_msg(cres, "chunk moved to "
					RAWX_LOSTFOUND_FOLDER);
	}
	g_string_free(dst_dir, TRUE);
	g_string_free(src_file, TRUE);

	return ret;
}

static gboolean
_reinit_ctx(struct meta2_ctx_s **p_ctx,
		struct content_textinfo_s *content_info, GError **p_err)
{
	gboolean ret = FALSE;
	struct meta2_ctx_s *new_ctx = NULL;
	gchar* ns = NULL;

	if (!p_ctx)
		return FALSE;

	ns = g_strdup((*p_ctx)->ns);

	// clear old ctx
	content_check_ctx_clear(*p_ctx);
	*p_ctx = NULL;

	// create new ctx
	new_ctx = get_meta2_ctx(ns, content_info->container_id,
			content_info->path, TRUE, p_err);
	if (!new_ctx) {
		GRID_DEBUG("Failed to get meta2 context (reloaded), check your NS is started. (NS:%s)", ns);
		goto clean_up;
	}
	if (new_ctx->loc == NULL || new_ctx->loc->m2_url == NULL) {
		GRID_DEBUG("Failed to locate container on a meta2 (reloaded) [%s][%s/%s]",
				content_info->container_id, new_ctx->ns, new_ctx->loc->container_name);
		goto clean_up;
	}

	*p_ctx = new_ctx;
	ret = TRUE;

clean_up:
	g_free(ns);
	return ret;
}

static gboolean
_is_newer_than_content(struct meta2_raw_content_s *content,
		check_info_t *check_info, gboolean *p_same_age)
{
	gint64 date_in_m2 = 0;
	gint64 date_in_extd_attr = 0;

	if (content->system_metadata)
		date_in_m2 = _extract_date_from_sysmd(
				content->system_metadata->data,
				content->system_metadata->len);

	if (check_info->ct_info->system_metadata)
		date_in_extd_attr = _extract_date_from_sysmd(
				(guint8*) check_info->ct_info->system_metadata,
				strlen(check_info->ct_info->system_metadata));

	if (p_same_age)
		*p_same_age = (date_in_m2 == date_in_extd_attr);

	return date_in_extd_attr > date_in_m2;
}

static gboolean
_recreate_content(struct meta2_ctx_s *ctx, check_info_t *check_info,
		check_result_t *cres, GError **p_err)
{
	GError *local_error = NULL;
	gboolean ret = FALSE;
	gchar *content_path = check_info->ct_info->path;

	local_error = _content_remove(ctx, check_info, cres);
	if (local_error) {
		GRID_DEBUG("Failed to remove content [%s] from container [%s/%s] (%s)",
				content_path, ctx->ns, ctx->loc->container_name, local_error->message);
		goto clean_up;
	} else {
		GRID_DEBUG("Content [%s] removed from container [%s/%s]",
				content_path, ctx->ns, ctx->loc->container_name);
	}
	local_error = _content_fill(ctx, check_info);
	if (local_error)
		goto clean_up;

	if (!_add_missing_chunk(ctx, check_info, cres, &local_error))
		goto clean_up;

	ret = TRUE;

clean_up:
	_set_or_free_error(local_error, p_err);
	return ret;
}

static gboolean
_overwrite_chunk_id(check_info_t *ci, check_result_t *cres,
		GError **p_err)
{
	const gboolean is_dryrun = check_option_get_bool(ci->options,
			CHECK_OPTION_DRYRUN);
	GError *err = NULL;
	gboolean ret = FALSE;

	if (is_dryrun) {
		GRID_DEBUG("Skipping overwriting of chunk.id (dryrun)");
		check_result_append_msg(cres, "dryrun prevented from overwriting"
				" chunk.id with: %s", ci->ck_info->id);
	} else {
		GRID_DEBUG("Overwriting chunk.id with: %s", ci->ck_info->id);
		if (!set_chunk_info_in_attr(ci->source_path, &err, ci->ck_info))
			goto end;
		check_result_append_msg(cres, "Xattr 'chunk.id' "
				"overwritten with: %s", ci->ck_info->id);
		ret = TRUE;
	}

end:
	_set_or_free_error(err, p_err);
	return ret;
}

static gboolean
_overwrite_chunk_creation_date(struct meta2_ctx_s *ctx,
		check_info_t *check_info, check_result_t *cres, GError **p_err)
{
	const gboolean is_dryrun = check_option_get_bool(check_info->options,
			CHECK_OPTION_DRYRUN);
	const GByteArray *sysmd = ctx->content->system_metadata;
	GError *err = NULL;
	gboolean ret = FALSE;
	gint64 date_in_m2 = 0;
	GByteArray *pack = NULL;
	GHashTable *unpacked = NULL;

	if (sysmd)
		date_in_m2 = _extract_date_from_sysmd(sysmd->data, sysmd->len);

	// overwrite creation date in metadata hashtable
	unpacked = metadata_unpack_string(check_info->ct_info->system_metadata, &err);
	if (!err) {
		metadata_add_printf(unpacked, "creation-date", "%"G_GINT64_FORMAT, date_in_m2);
	} else {
		goto exit;
	}

	// replace metadata
	g_free(check_info->ct_info->system_metadata);
	pack = metadata_pack(unpacked, &err);
	if (err)
		goto exit;
	check_info->ct_info->system_metadata = g_strndup((const gchar *)pack->data, pack->len);

	// write xattr to disk
	if (is_dryrun) {
		check_result_append_msg(cres, "dryrun prevented from overwriting chunk"
				" creation-date metadata with: %"G_GINT64_FORMAT, date_in_m2);
	} else {
		GRID_DEBUG("Overwriting creation-date in system metadata"
				" with new date: %"G_GINT64_FORMAT, date_in_m2);
		if (!set_content_info_in_attr(check_info->source_path, &err, check_info->ct_info))
			goto exit;
		check_result_append_msg(cres, "System metadata 'creation-date' "
				"overwritten with content date: %"G_GINT64_FORMAT, date_in_m2);
	}

	ret = TRUE;

exit:
	if (unpacked)
		g_hash_table_destroy(unpacked);
	if (pack)
		g_byte_array_free(pack, TRUE);
	_set_or_free_error(err, p_err);

	return ret;
}

static int
_volumes_cmp0(const gchar *vol1, const gchar *vol2)
{
	GString *str_vol1 = g_string_new(vol1);
	GString *str_vol2 = g_string_new(vol2);
	int ret;

	if (str_vol1->str[str_vol1->len - 1] != G_DIR_SEPARATOR)
		g_string_append_c(str_vol1, G_DIR_SEPARATOR);
	if (str_vol2->str[str_vol2->len - 1] != G_DIR_SEPARATOR)
		g_string_append_c(str_vol2, G_DIR_SEPARATOR);

	ret = g_strcmp0(str_vol1->str, str_vol2->str);

	g_string_free(str_vol1, TRUE);
	g_string_free(str_vol2, TRUE);

	return ret;
}

gboolean
check_chunk_orphan(check_info_t *ci, check_result_t *cres, GError **p_err)
{
	check_info_t *check_info = check_info_dup(ci);
	const gboolean is_dryrun = check_option_get_bool(check_info->options,
			CHECK_OPTION_DRYRUN);
	gboolean ret = FALSE, is_referenced = FALSE, has_extension = FALSE;
	GSList *broken_elements = NULL;
	struct meta2_ctx_s *ctx = NULL;
	struct content_textinfo_s *content_info = check_info->ct_info;
	gchar *src_basename = NULL;
	struct meta2_raw_chunk_s *raw_chunk = NULL;
	GError *err = NULL;
	gboolean same_age, is_chunk_newer;

	// find container and content
	ctx = get_meta2_ctx(check_info->ns_name, content_info->container_id,
			content_info->path, TRUE, &err);

	if (err) {
		if (err->code > 0 && CODE_IS_NETWORK_ERROR(err->code))
			goto clean_up;
		// errors will be repaired, discard what was detected in get_meta2_ctx
		g_clear_error(&err);
	}

	if (!ctx) {
		GRID_DEBUG("Failed to get meta2 context, check your NS is started. (NS:%s)", check_info->ns_name);
		goto clean_up;
	}

	// if container NOT FOUND on meta1, trash chunk and exit successfully
	// if ctx->loc == NULL: cid not referenced on meta1
	if (ctx->loc == NULL) {
		if (trash_chunk(check_info, cres))
			check_result_append_msg(cres, "(container [%s] not found on meta1)",
					content_info->container_id);
		goto success;
	}

	// if   service's container NOT FOUND on meta1, create it
	// elif service's container FOUND on meta1, check if container really exist on meta2_url
	//            container and service found on meta1,
	//            if content not found: check if container exist on meta2
	if (!ctx->loc->m2_url || !ctx->content) {
		if (is_dryrun) {
			check_result_append_msg(cres, "Content [%s/%s] not found "
					"(not fixable in dryrun mode)",
					content_info->container_id, content_info->path);
			goto success;
		}
		// check / create
		if (!_ensure_container_created(ctx, check_info, cres, &err)) {
			GRID_DEBUG("Giving up chunk integration (no container).");
			goto clean_up;
		}

		if (ctx->loc->m2_url == NULL) {
			if (!_reinit_ctx(&ctx, check_info->ct_info, &err))
				goto clean_up;
		}

		g_clear_error(&err);
	}

	// if content not found, try to find content from chunk id
	if (!ctx->content) {
		g_clear_error(&err);
		if (!_find_content_from_chunkid(ctx, check_info, &err)) {
			if (err && err->code != CODE_NOT_FOUND && err->code != CODE_CONTENT_NOTFOUND)
				goto clean_up;
			g_clear_error(&err);
			err = _content_fill(ctx, check_info);
			if (err)
				goto clean_up;
			check_result_append_msg(cres, "Content [%s] in container [%s]"
					" will be created.",
					content_info->path, content_info->container_id);
		}
	}

	// content->raw_chunks may be null if content was just created
	if (ctx->content->raw_chunks) {
		// check if chunk is well referenced in meta2
		raw_chunk = _get_chunk(ctx->content->raw_chunks, check_info->ck_info);
		is_referenced = check_chunk_referencing_full(content_info, check_info->ck_info,
				ctx->content, raw_chunk, &broken_elements, &err);
		is_chunk_newer = _is_newer_than_content(ctx->content, check_info, &same_age);

		if (is_referenced) {
			// rawx volume check
			if (0 != _volumes_cmp0(raw_chunk->id.vol, check_info->rawx_vol)) {
				check_result_append_msg(cres,
						"rawx mismatch (volume found in m2: [%s])",
						raw_chunk->id.vol);
				is_referenced = FALSE;
			} else {
				if (!same_age)
					if (!_overwrite_chunk_creation_date(ctx, check_info, cres, &err))
						goto clean_up;
			}
		} else {
			// if chunk is newer than the content it refers to, re-create content
			// if both have the same date, everything is ok
			// if chunk is older, trash it and exit successfully
			if (is_chunk_newer) {
				check_result_append_msg(cres, "Recreate content [%s/%s] (chunk is newer)",
						check_info->ct_info->container_id,
						check_info->ct_info->path);
				if (!_recreate_content(ctx, check_info, cres, &err))
					goto clean_up;
				is_referenced = TRUE;
			} else if (same_age) {
				// nothing to do here, the chunk will be added
				GRID_DEBUG("Crawled chunk has the same date as content (OK)");
			} else {
				// crawled chunk is older than content, trash it
				if (trash_chunk(check_info, cres))
					check_result_append_msg(cres, "(chunk too old)");
				goto success;
			}
		}
	}

	src_basename = g_path_get_basename(check_info->source_path);
	has_extension = (NULL != strchr(src_basename, '.'));

	// if chunk is not referenced at all, add it
	if (!is_referenced) {
		// handles .pending chunk: if not referenced, trash
		if (has_extension) {
			if (trash_chunk(check_info, cres))
				check_result_append_msg(cres, "(unreferenced .pending)");
		} else {
			if (!_add_missing_chunk(ctx, check_info, cres, &err))
				goto clean_up;
		}
	} else {
		// handles .pending chunk: if referenced and md5 ok, remove extension
		if (has_extension && !broken_elements) {
			if (_check_chunk_pending(check_info, cres))
				goto success;
			goto clean_up;
		}
		// chunk is referenced in meta2, print broken elements if any
		if (broken_elements) {
			_append_brk_el_to_result(content_info, broken_elements, cres);

			// handles .pending: move to trash
			if (has_extension) {
				if (trash_chunk(check_info, cres))
					check_result_append_msg(cres, "(.pending with broken elements)");
				goto success;
			}
		} else {
			if (cres && cres->msg == NULL) {
				cres->check_ok = TRUE;
				GRID_DEBUG("Chunk [%s] is well referenced.", check_info->ck_info->id);
			}
		}
	}

success:
	ret = TRUE;

clean_up:
	g_free(src_basename);
	content_check_ctx_clear(ctx);
	g_slist_free_full(broken_elements, broken_element_free);
	_set_or_free_error(err, p_err);
	check_info_free(check_info);

	return ret;
}

gboolean
check_chunk_id_parsable(check_info_t *check_info, check_result_t *cres, GError **p_err)
{
	GError *err = NULL;
	gboolean ret = FALSE;
	gboolean id_overwritten = FALSE;
	gchar *file_name = NULL, *previous_id = NULL;
	check_info_t *ci = check_info_dup(check_info);
	hash_sha256_t h;

	if (!(cres->check_ok = hex2bin(ci->ck_info->id, &h, sizeof(h), &err))) {
		file_name = g_path_get_basename(ci->source_path);
		GRID_DEBUG("Could not convert chunk.id to binary, try again conversion "
				"with chunk id regenerated from filename: [%s].", file_name);
		previous_id = ci->ck_info->id;
		// only copy the first 64 chars as there may be an extension
		ci->ck_info->id = g_strndup(file_name, STRLEN_CHUNKID);
		g_clear_error(&err);
		if (!hex2bin(ci->ck_info->id, &h, sizeof(h), &err))
			goto end;
		GRID_DEBUG("Conversion succeeded using chunkid: %s", ci->ck_info->id);
		if (!(id_overwritten = _overwrite_chunk_id(ci, cres, &err)))
			goto end;
		GRID_DEBUG("Xattr overwritten.");
	}

	ret = TRUE;

end:
	_set_or_free_error(err, p_err);

	if (previous_id) {
		g_free(file_name);
		if (id_overwritten) {
			g_free(previous_id);
		} else {
			g_free(ci->ck_info->id);
			ci->ck_info->id = previous_id;
		}
	}

	check_info_free(ci);
	return ret;
}
