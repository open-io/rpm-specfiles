/*
OpenIO SDS integrity
Copyright (C) 2014 Worldine, original work as part of Redcurrant
Copyright (C) 2015 OpenIO, modified as part of OpenIO Software Defined Storage

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef G_LOG_DOMAIN
#define G_LOG_DOMAIN "integrity.lib.check"
#endif

#include <metautils/lib/metautils.h>
#include <cluster/lib/gridcluster.h>
#include <meta2v2/meta2_remote.h>
#include <meta2v2/meta2v2_remote.h>
#include <meta2v2/generic.h>
#include <meta2v2/meta2_utils.h>

#include <integrity/lib/check.h>

static GError*
_init_meta2_connection(struct meta2_ctx_s *ctx)
{
	ctx->m2_cnx = metacnx_create();
	ctx->m2_cnx->flags = METACNX_FLAGMASK_KEEPALIVE;
	ctx->m2_cnx->timeout.cnx = 30000;
	ctx->m2_cnx->timeout.req = 30000;

	GError *result = NULL;
	if (!metacnx_init_with_url(ctx->m2_cnx, ctx->loc->m2_url[0], &result))
		goto clean_up;
	if (!metacnx_open(ctx->m2_cnx, &result))
		goto clean_up;

clean_up:
	if(result) {
		if(ctx->m2_cnx) {
			metacnx_close(ctx->m2_cnx);
			metacnx_destroy(ctx->m2_cnx);
			ctx->m2_cnx = NULL;
		}
	}	

	return result;
}

struct meta2_ctx_s *
get_meta2_ctx(const gchar *ns_name, const gchar *container_hexid,
		const gchar *content_name, gboolean check_only, GError **error)
{
	gchar *storage_policy = NULL;
	namespace_info_t *ns_info = NULL;
	GError *local_error = NULL;
	gs_error_t *gs_error = NULL;
	struct meta2_ctx_s *ctx = NULL;

	/* load namespace info for storage policies definitions */
	if(!(ns_info = get_namespace_info(ns_name, &local_error))) {
		GSETCODE(error, local_error ? local_error->code : 0,
				"Failed to load namespace info, cannot check content policy: %s",
				local_error ? local_error->message : "<no details>");
		goto clean_up;
	}

	ctx = g_malloc0(sizeof(struct meta2_ctx_s));

	ctx->ns = g_strdup(ns_info->name);
	ctx->check_only = check_only;
	ctx->modified = FALSE;
	ctx->fail = FALSE;

	GRID_DEBUG("Namespace info ok");

	if(!(ctx->hc = gs_grid_storage_init(ns_name, &gs_error))) {
		GSETERROR(error, "Failed to init grid storage client : %s", gs_error_get_message(gs_error));
		goto clean_up;
	}

	GRID_DEBUG("context initialization ok");

	/* Locate container */
	if (!container_hexid) {
		GSETERROR(error, "Container is null");
		goto clean_up;
	}

	char* ct_ns_name = NULL;
	ctx->loc = gs_locate_container_by_hexid_v2(ctx->hc, container_hexid, &ct_ns_name, &gs_error);
	if (ctx->loc == NULL || ctx->loc->m2_url == NULL) {
		GSETCODE(error, gs_error_get_code(gs_error),
				"Failed to locate container [%s] in namespace: %s",
				container_hexid, gs_error_get_message(gs_error));
	}

	// if nsname --> replace by realy VNS name
	if (ct_ns_name) {
        if (g_strcmp0(ct_ns_name, ctx->ns) != 0) {
            g_free(ctx->ns);
            ctx->ns = ct_ns_name;

            // close old hc
			gs_grid_storage_free(ctx->hc);

			// reinit hc with VNS name
			if(!(ctx->hc = gs_grid_storage_init(ctx->ns, &gs_error))) {
	        	GSETCODE(error, gs_error_get_code(gs_error),
	        			"Failed to init grid storage client: %s",
						gs_error_get_message(gs_error));
				goto clean_up;
			}
		} else {
			g_free(ct_ns_name);
		}
	}

	// exit if container not loaded
	if (ctx->loc == NULL || ctx->loc->m2_url == NULL)
		goto clean_up;

	GRID_DEBUG("container located [%s/%s]", ctx->ns, ctx->loc->container_name);

	if((local_error = _init_meta2_connection(ctx)) != NULL) {
		GSETCODE(error, local_error->code,
				"Failed to init meta2 connection: %s",
				local_error->message);
		goto clean_up;
	}

	do {
		struct hc_url_s *url = hc_url_empty ();
		hc_url_set (url, HCURL_NS, ns_name);
		hc_url_set (url, HCURL_HEXID, container_hexid);
		hc_url_set (url, HCURL_PATH, content_name);
		ctx->content = meta2_remote_stat_content(ctx->m2_cnx, &local_error, url);
		hc_url_clean (url);
	} while (0);

	if (!ctx->content) {
		GRID_DEBUG("Content %s/%s/%s doesn't exist", ctx->ns,
				container_hexid, content_name);
		if (local_error) {
			GSETCODE(error, local_error->code,
					"Cannot check content state, "
					"content not found %s/%s/%s: %s",
					ctx->ns, container_hexid, content_name,
					local_error->message);
		}
		goto clean_up;
	}

	GRID_DEBUG("Content information:");
	GRID_DEBUG("Nb chunks: %"G_GUINT32_FORMAT, ctx->content->nb_chunks);
	GRID_DEBUG("Size: %"G_GINT64_FORMAT, ctx->content->size);
	if(ctx->content->metadata)
		GRID_DEBUG("Metadata : %s", (gchar*)ctx->content->metadata->data);
	else
		GRID_DEBUG("No metadata returned");

	local_error = storage_policy_from_metadata(ctx->content->system_metadata,
			&storage_policy);
	if (local_error != NULL || !storage_policy) {
		storage_policy = namespace_storage_policy(ns_info, ctx->ns);
		if (!storage_policy) {
			GSETERROR(error, "Failed to get content storage policy, "
					"cannot check it");

			goto clean_up;
		} else {
			GRID_INFO("No storage policy defined for content, "
					"will use default from namespace: %s", storage_policy);
		}
	}

	ctx->sp = storage_policy_init(ns_info, storage_policy);

clean_up:

	if(storage_policy)
		g_free(storage_policy);

	if(local_error) {
		g_clear_error(&local_error);
		local_error = NULL;
	}
	if(gs_error) {
		gs_error_free(gs_error);
		gs_error = NULL;
	}

	if(ns_info) {
		namespace_info_free(ns_info);
	}
	return ctx;
}

GError *
generate_raw_chunk(check_info_t *info,
		struct meta2_raw_chunk_s *p_raw_chunk)
{
	GError *err = NULL;
	gchar *id_first_char;

	if (!convert_chunk_text_to_raw(info->ck_info, p_raw_chunk, &err)) {
		GRID_INFO("Could not convert text chunk_info to raw [%s]",
				err ? err->message : "no details");
		// Failed conversion may occur upon corrupted chunk id found in attr.
		// Try again with a chunk id generated from file path.
		if (!(id_first_char = strrchr(info->source_path,'/')))
			return err;
		id_first_char++;
		GRID_INFO("Try again conversion with chunk id regenerated from chunk path: [%s].",
				id_first_char);
		g_free(info->ck_info->id);
		// only copy the first 64 chars as there may be an extension
		info->ck_info->id = g_strndup(id_first_char, STRLEN_CHUNKID - 1);
		g_clear_error(&err);
		if (!convert_chunk_text_to_raw(info->ck_info, p_raw_chunk, &err)) {
			g_prefix_error(&err, "Could not convert text chunk_info to raw: [%s]",
					info->ck_info->id);
			return err;
		}
		GRID_INFO("Conversion succeeded.");
	}

	return NULL;
}

void check_result_append_msg(check_result_t *res, const gchar *format, ...)
{
	va_list args;

	if (res) {
		res->check_ok = FALSE;
		if (!res->msg)
			res->msg = g_string_new("");
		else
			g_string_append(res->msg, " ");
		va_start(args, format);
		g_string_append_vprintf(res->msg, format, args);
		va_end(args);
	}
}

void check_result_clear(check_result_t **p_res, void (*free_udata(gpointer)))
{
	if (p_res && *p_res) {
		if ((*p_res)->msg)
			g_string_free((*p_res)->msg, TRUE);
		if ((*p_res)->udata && free_udata)
			free_udata((*p_res)->udata);
		g_free(*p_res);
		*p_res = NULL;
	}
}

check_result_t *
check_result_new (void)
{
	return g_malloc0(sizeof(check_result_t));
}

static GError*
_find_sp_fc_m2v2(const gchar* meta2,
		struct hc_url_s *url, check_info_t *check_info, GSList **chunk_ids)
{
	GError *err = NULL;
	GString *policy = NULL;
	GSList *beans = NULL;
	struct chunk_textinfo_s *chunk_info = check_info->ck_info;
	struct content_textinfo_s *content_info = check_info->ct_info;
	gchar *chunk_id;
	// timeouts are expressed in seconds in m2v2
	gdouble m2to = META2_TIMEOUT / 1000.0;

	chunk_id = assemble_chunk_id(check_info->rawx_str_addr,
			check_info->rawx_vol, chunk_info->id);

	GRID_DEBUG("Url to perform GET_BY_CHUNK: [%s]",
			hc_url_get(url, HCURL_WHOLE));
	GRID_DEBUG("Chunk id to look for: [%s]", chunk_id);

	err = m2v2_request(meta2,
			m2v2_remote_pack_GET_BY_CHUNK(url, chunk_id, 1),
			m2to, &beans);
	if (err != NULL) {
		g_prefix_error(&err, "Could not get contents referencing chunk %s: ",
				chunk_id);
		goto clean_up;
	} else {
		for (GSList *cursor = beans; cursor; cursor = cursor->next) {
			if (DESCR(cursor->data) == &descr_struct_CONTENTS_HEADERS) {
				GString *policy2 = CONTENTS_HEADERS_get_policy(cursor->data);
				if (policy != NULL && policy->len > 0 &&
						policy2 != NULL && policy2->len > 0 &&
						!g_string_equal(policy, policy2)) {
					err = NEWERROR(0, "Found 2 different policies for the same"
							" chunk!!! '%s' and '%s'", policy->str, policy2->str);
					goto clean_up;
				} else {
					policy = policy2;
				}
			} else if (DESCR(cursor->data) == &descr_struct_CONTENTS) {
				gint pos1, pos2;
				gint _sub; // don't care
				gboolean _par; // don't care
				GString *position = CONTENTS_get_position(cursor->data);
				m2v2_parse_chunk_position(position->str, &pos1, &_par, &_sub);
				m2v2_parse_chunk_position(chunk_info->position,
						&pos2, &_par, &_sub);
				// consider chunk only if same position
				if (pos1 == pos2) {
					GString *chunkid = CONTENTS_get_chunk_id(cursor->data);
					*chunk_ids = g_slist_prepend(*chunk_ids,
							g_strdup(chunkid->str));
				}
			} else if (DESCR(cursor->data) == &descr_struct_ALIASES) {
				GString *alias = ALIASES_get_alias(cursor->data);
				gint64 version = ALIASES_get_version(cursor->data);
				GRID_DEBUG("Chunk belongs to '%s' version %ld",
						alias->str, version);
				if (content_info->version == NULL) {
					if (NULL == content_info->path)
						content_info->path = g_strdup(alias->str);
					content_info->version = g_strdup_printf("%"G_GUINT64_FORMAT, version);
				}
			}
		}
		if (policy && policy->len == 0) {
			policy = NULL;
		}
		if (policy) {
			policy = g_string_new(policy->str); // make a copy before cleaning
		}
	}
	if (policy) {
		content_info->storage_policy = g_string_free(policy, FALSE);
		GRID_DEBUG("Storage policy found in content header: '%s'",
				content_info->storage_policy);
	}

clean_up:
	if (err != NULL) {
		g_slist_free_full(*chunk_ids, g_free);
		*chunk_ids = NULL;
	}
	g_free(chunk_id);
	_bean_cleanl2(beans);
	return err;
}

GError*
find_storage_policy_and_friend_chunks_full(const gchar* meta2,
		struct hc_url_s *url, check_info_t *check_info,
		GSList **chunk_ids, struct meta2_raw_content_s **p_raw_content)
{
	GError *err = NULL, *err2 = NULL;

		GRID_DEBUG("Trying with M2V2 request on m2 [%s] for chunk [%s]",
				meta2, check_info->ck_info->id);
		err = _find_sp_fc_m2v2(meta2, url, check_info, chunk_ids);
		if (!err) {
			if (p_raw_content) {
				if (*p_raw_content)
					meta2_raw_content_clean(*p_raw_content);
				*p_raw_content = g_malloc0(sizeof(struct meta2_raw_content_s));
				convert_content_text_to_raw(check_info->ct_info, *p_raw_content, &err);
			}
			return err;
		}

	if (err2) {
		g_clear_error(&err);
		return err2;
	}

	return err;
}

GError*
find_storage_policy_and_friend_chunks(const gchar* meta2,
		struct hc_url_s *url, check_info_t *check_info, GSList **chunk_ids)
{
	return find_storage_policy_and_friend_chunks_full(
			meta2, url, check_info, chunk_ids, NULL);
}

GHashTable *
check_option_new (void)
{
	return g_hash_table_new_full(g_str_hash, g_str_equal, g_free, g_free);
}

void
check_option_destroy(GHashTable *options)
{
	if (options)
		g_hash_table_destroy(options);
}

static gpointer
_get_option(GHashTable *options, const gchar *option_name)
{
	if (!options || !option_name)
		return NULL;
	return g_hash_table_lookup(options, option_name);
}

static void
_set_option(GHashTable *options,
		const gchar *oname, gpointer ovalue)
{
	if (options && oname)
		g_hash_table_insert(options, g_strdup(oname), ovalue);
}

gint
check_option_get_int(GHashTable *options, const gchar *option_name)
{
	gchar *optval = _get_option(options, option_name);
	if (optval)
		return g_ascii_strtoll(optval, NULL, 10);
	return G_MAXINT;
}

gboolean
check_option_get_bool(GHashTable *options, const gchar *option_name)
{
	gchar *optval = _get_option(options, option_name);
	if (optval)
		return g_ascii_strtoll(optval, NULL, 10);
	return FALSE;
}

gchar*
check_option_get_str(GHashTable *options, const gchar *option_name)
{
	gchar *optval = _get_option(options, option_name);
	return optval;
}

void
check_option_set_int(GHashTable *options,
		const gchar *oname, gint ovalue)
{
	_set_option(options, oname, g_strdup_printf("%i", ovalue));
}

void
check_option_set_bool(GHashTable *options,
		const gchar *oname, gboolean ovalue)
{
	check_option_set_int(options, oname, ovalue);
}

void
check_option_set_str(GHashTable *options,
		const gchar *oname, const gchar *ovalue)
{
	_set_option(options, oname, g_strdup(ovalue));
}

#define DUPSTR(F) do { newci->F = g_strdup(src->F); } while (0)

static chunk_textinfo_t*
_chunk_textinfo_dup(chunk_textinfo_t *src)
{
	chunk_textinfo_t *newci = NULL;

	if (src == NULL)
		return NULL;

	newci = g_malloc0(sizeof(chunk_textinfo_t));
	DUPSTR(id);
	DUPSTR(path);
	DUPSTR(size);
	DUPSTR(position);
	DUPSTR(hash);
	DUPSTR(metadata);
	DUPSTR(container_id);

	return newci;
}

static content_textinfo_t*
_content_textinfo_dup(content_textinfo_t *src)
{
	content_textinfo_t *newci = NULL;

	if (src == NULL)
		return NULL;

	newci = g_malloc0(sizeof(content_textinfo_t));
	DUPSTR(container_id);
	DUPSTR(path);
	DUPSTR(size);
	DUPSTR(chunk_nb);
	DUPSTR(metadata);
	DUPSTR(system_metadata);
	DUPSTR(storage_policy);
	DUPSTR(rawx_list);
	DUPSTR(spare_rawx_list);
	DUPSTR(version);

	return newci;
}

#undef DUPSTR

static GHashTable*
_check_options_dup(GHashTable *src)
{
	GHashTable *newci = NULL;

	if (src == NULL)
		return NULL;

	newci = check_option_new();
	void _copy_option(gpointer _key, gpointer _val, gpointer _udata)
	{
		const gchar *key = _key;
		const gchar *val = _val;
		(void) _udata;
		g_hash_table_insert(newci, g_strdup(key), g_strdup(val));
	}
	g_hash_table_foreach(src, _copy_option, NULL);

	return newci;
}

check_info_t*
check_info_dup(check_info_t *src)
{
	check_info_t *newci = g_malloc0(sizeof(check_info_t));

#define COPYARRAY(F) do { memcpy(newci->F, src->F, sizeof(newci->F)); } while (0)
	COPYARRAY(ns_name);
	COPYARRAY(rawx_str_addr);
	COPYARRAY(rawx_vol);
	COPYARRAY(source_path);
#undef COPYARRAY

	newci->ck_info = _chunk_textinfo_dup(src->ck_info);
	newci->ct_info = _content_textinfo_dup(src->ct_info);
	newci->options = _check_options_dup(src->options);

	return newci;
}

void
check_info_free(check_info_t *ci)
{
	if (ci == NULL)
		return;
	chunk_textinfo_free_content(ci->ck_info);
	content_textinfo_free_content(ci->ct_info);
	check_option_destroy(ci->options);
	g_free(ci->ck_info);
	g_free(ci->ct_info);
	g_free(ci);
}
