/*
OpenIO SDS integrity
Copyright (C) 2014 Worldine, original work as part of Redcurrant
Copyright (C) 2015 OpenIO, modified as part of OpenIO Software Defined Storage

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef OIO_SDS__integrity__lib__meta2_check_h
# define OIO_SDS__integrity__lib__meta2_check_h 1

/**
 * @defgroup integrity_loop_lib_meta2_check META2 related checks
 * @ingroup integrity_loop_lib
 * @{
 */

#include <metautils/lib/metautils.h>
 
/**
 * Execute maintenance (mainly vacuum) on SQLITE database
 *
 * @param meta2_db_path the fullp ath to the META2 database
 * @param error
 *
 * @return TRUE or FALSE if an error occured
 *
 * - Execute VACUUM command on sqlite database
 */
gboolean meta2_sqlite_maintenance(const gchar* meta2_db_path, GError **error);

/**
 * Check chunk properties consistancy between chunk from META2 and chunk from RAWX
 *
 * @param raw_content a meta2_raw_content struct containing only the chunk to check
 * @param broken a list of broken_element struct
 * @param error
 *
 * @return TRUE or FALSE if an error occured
 *
 * - Use rawx_client_get_direcoty_data() to retreive the content/chunk infos from the RAWX
 * - Use the check_chunk_referencing() function to find diffs
 */
gboolean check_meta2_chunk(const struct meta2_raw_content_s* raw_content, GSList** broken, GError** error);

/** @} */

#endif /*OIO_SDS__integrity__lib__meta2_check_h*/