/*
OpenIO SDS client
Copyright (C) 2014 Worldine, original work as part of Redcurrant
Copyright (C) 2015 OpenIO, modified as part of OpenIO Software Defined Storage

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 3.0 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library.
*/

#ifndef G_LOG_DOMAIN
# define G_LOG_DOMAIN "grid.client"
#endif

#include <glib.h>
#include "./gs_internals.h"

long unsigned int wait_on_add_failed = 1000LU;

static void
env_init (void)
{
	static volatile guint lazy_init = 1;

	if (lazy_init) {
		if (g_atomic_int_compare_and_exchange(&lazy_init, 1, 0)) {
			const gchar *s;

			if (NULL != (s = getenv(ENV_GLIB2_ENABLE)))
				g_log_set_default_handler(logger_stderr, NULL);

			/*configure the sleep time between two failed ADD actions*/
			wait_on_add_failed = 10000UL;
			if (NULL != (s = getenv(ENV_WAIT_ON_FAILED_ADD))) {
				gint64 i64 = g_ascii_strtoll (s, NULL, 10 );
				if (i64>=0LL && i64<=10000LL)
					wait_on_add_failed = i64;
			}
		}
	}
}

int
gs_set_namespace(gs_grid_storage_t *gs, const char *vns)
{
	if (!gs)
		return 0;

	if (vns && !g_str_has_prefix(vns, gs->physical_namespace))
		return 0;

	metautils_str_replace (&gs->ns, vns);
	return 1;
}

const char*
gs_get_namespace(gs_grid_storage_t *gs)
{
	return !gs ? NULL : gs->physical_namespace;
}

const char*
gs_get_virtual_namespace(gs_grid_storage_t *gs)
{
	if (!gs) return NULL;
	char *s = strchr(gs->ns, '.');
	return (s!=NULL) ? s+1 : NULL;
}

const char*
gs_get_full_namespace(gs_grid_storage_t *gs)
{
	if (!gs) return NULL;
	return gs->ns ? gs->ns : gs->physical_namespace;
}

gs_grid_storage_t*
gs_grid_storage_init_flags(const gchar *ns, uint32_t flags,
		int to_cnx, int to_req, gs_error_t **err)
{
	logger_lazy_init ();
	env_init();

	/*parse the arguments*/
	if (!ns || !*ns) {
		GSERRORSET(err,"Invalid parameter");
		return NULL;
	}

	gs_grid_storage_t *gs = g_malloc0(sizeof(gs_grid_storage_t));

	/* inits a new gs_grid_storage_t */
	if (!(flags & GSCLIENT_NOINIT)) {
		GError *e = NULL;
		gs->ni = get_namespace_info(ns, &e);
		if (!gs->ni) {
			GSERRORCAUSE(err,e,"Cannot get namespace info");
			if (e)
				g_clear_error(&e);
			g_free(gs);
			return NULL;
		}
	}

	/* unpack NS and VNS if any */
	const gchar *sep;
	if (NULL != (sep = strchr(ns, '.')))
		gs->physical_namespace = g_strndup(ns, sep-ns);
	else
		gs->physical_namespace = g_strdup(ns);
	gs->ns = g_strdup(ns);

	if (!(flags & GSCLIENT_NOINIT)) {
		GError *e = NULL;
		gs->direct_resolver = resolver_direct_create2 (ns, to_cnx, to_req, &e);
		if (!gs->direct_resolver) {
			GSERRORCAUSE(err,e,"Cannot init the direct resolver");
			if (e)
				g_clear_error(&e);
			g_free(gs);
			return NULL;
		}
	}

	gs->timeout.rawx.op =  RAWX_TOREQ_DEFAULT;
	gs->timeout.rawx.cnx = RAWX_TOCNX_DEFAULT;
	gs->timeout.m2.op =   M2_TOREQ_DEFAULT;
	gs->timeout.m2.cnx =  M2_TOCNX_DEFAULT;

	return gs;
}

gs_grid_storage_t*
gs_grid_storage_init2(const gchar *ns, int to_cnx, int to_req,
		gs_error_t **err)
{
	return gs_grid_storage_init_flags(ns, 0, to_cnx, to_req, err);
}

gs_grid_storage_t*
gs_grid_storage_init (const gchar *ns, gs_error_t **err)
{
	return gs_grid_storage_init_flags(ns, 0, CS_TOCNX_DEFAULT, CS_TOREQ_DEFAULT, err);
}

int
gs_update_meta1_master (gs_grid_storage_t *gs, const container_id_t cID,
		const char *m1)
{
	int attempts = NB_ATTEMPTS_UPDATE_M1;

	int _try (void) {
		GError *e = NULL;

		if ((attempts--) <= 0) {
			//leak memory, e not free
			return 0;
		}

		if(!resolver_direct_set_meta1_master (gs->direct_resolver, cID, m1, &e))
			DEBUG("META1 update failure. Cause: %s",(e ? e->message : "?"));
			if(NULL != e)
				g_clear_error(&e);
			return _try();
		return 1;
	}

	return _try();
}

addr_info_t*
gs_resolve_meta1v2_v2(gs_grid_storage_t *gs, const container_id_t cID,
		const gchar *cname, int read_only, GSList **exclude,
		gboolean has_before_create, GError **err)
{
	gchar str_cid[STRLEN_CONTAINERID];
	int attempts=NB_ATTEMPTS_RESOLVE_M1;
	GError *gErr=NULL;

	struct hc_url_s *url = fill_hcurl_from_client (gs);
	hc_url_set (url, HCURL_USER, cname);

	addr_info_t* _try (void) {
		addr_info_t *pA=NULL;

		if ((attempts--)<=0) {
			GSETERROR(&gErr,"too many attempts");
			return NULL;
		}

		if (NULL == pA) {
			pA = resolver_direct_get_meta1(gs->direct_resolver, cID, read_only,
					exclude? *exclude:NULL, &gErr);
			if (!pA)
				return _try();
		}

		if (NULL == cname)
			return pA;

			if (has_before_create) {
				if (meta1v2_remote_has_reference(pA, &gErr, url)) {
					DEBUG("METACD reference already exists in meta1: [%s/%s]",
							cname, str_cid);
					return pA;
				} else if (gErr && gErr->code == CODE_CONTAINER_NOTFOUND) {
					g_clear_error(&gErr);
				} else if (gErr && CODE_IS_NETWORK_ERROR(gErr->code)) {
					DEBUG("Network error (meta1 down?): %s", gErr->message);
					if (exclude != NULL)
						*exclude = g_slist_prepend(*exclude, pA);
					return _try();
				} else {
					WARN("METACD error checking reference [%s] in meta1: (%d) %s",
							str_cid, gErr?gErr->code:0, gErr?gErr->message:"?");
					g_clear_error(&gErr);
				}
				DEBUG("Creating reference in meta1: [%s/%s]", cname, str_cid);
			}
			if (meta1v2_remote_create_reference(pA, &gErr, url)) {
				DEBUG("METACD created reference in meta1: [%s/%s]",
						cname, str_cid);
			} else {
				if (gErr && gErr->code == CODE_CONTAINER_EXISTS) {
					DEBUG("METACD reference already exists in meta1: [%s/%s]",
							cname, str_cid);
				} else {
					DEBUG("METACD error creating reference [%s] in meta1: (%d) %s",
							str_cid, gErr?gErr->code:0, gErr?gErr->message:"?");
					GSETERROR(&gErr,"Could not create reference");
					if (exclude != NULL)
						*exclude = g_slist_prepend(*exclude, pA);
					/* if (err) *err = gErr; */
					return _try();
				}
			}

		return pA;
	}

	container_id_to_string(cID, str_cid, sizeof(str_cid));

	addr_info_t *resAddr = _try();
	if (!resAddr && err) {
		*err = gErr;
	} else {
		if (gErr)
			g_error_free(gErr);
	}
	hc_url_clean (url);
	return resAddr;
}

addr_info_t*
gs_resolve_meta1v2 (gs_grid_storage_t *gs, const container_id_t cID, const gchar *cname,
		int read_only, GSList **exclude, GError **err)
{
	// Do not set has_before_create to TRUE or container creation will
	// fail when metacd is present and one meta1 is broken
	return gs_resolve_meta1v2_v2(gs, cID, cname, read_only, exclude, FALSE, err);
}

addr_info_t*
gs_resolve_meta1 (gs_grid_storage_t *gs, container_id_t cID, GError **err)
{
	return gs_resolve_meta1v2(gs, cID, NULL, 0, NULL, err);
}

GSList*
gs_resolve_meta2 (gs_grid_storage_t *gs, struct hc_url_s *url, GError **err)
{
	int attempts=NB_ATTEMPTS_RESOLVE_M2;
	GError *gErr=NULL;
	GSList *m1_exclude = NULL;

	GSList* _try (GSList **exclude)
	{
		GSList *pL=NULL;

		if ((attempts--)<=0) {
			GSETERROR(&gErr,"too many attempts");
			return NULL;
		}

		/* between two meta2 direct resolutions, we want to
		 * be sure a metacd has not been spawned, so only
		 * one try is made this turn */
		pL = resolver_direct_get_meta2_once (gs->direct_resolver, url, exclude, &gErr);
		if (pL)
			return pL;

		if (gErr) {
			if (gErr->code==CODE_CONTAINER_NOTFOUND) {
				/*in this case, no need to retry*/
				return NULL;
			} else if (CODE_REFRESH_META0(gErr->code) ||
					CODE_IS_NETWORK_ERROR(gErr->code) ||
					gErr->code == CODE_INTERNAL_ERROR) {
				gs_decache_all( gs);
				return _try(exclude);
			}
		} else GSETERROR(&gErr,"Unknown error, not retrying a direct resolution");

		return NULL;
	}

	GSList *resList = _try(&m1_exclude);
	if (!resList) {
		if (err)
			*err = gErr;
		else if (gErr)
			g_error_free( gErr );
	}

	g_slist_free_full(m1_exclude, (GDestroyNotify) addr_info_clean);
	return resList;
}

void
gs_decache_container (gs_grid_storage_t *gs, container_id_t cID)
{
	(void) gs, (void) cID;
}

void
gs_decache_all (gs_grid_storage_t *gs)
{
	resolver_direct_decache_all (gs->direct_resolver);
}

static void
_fill_meta1_tabs(char ***p_m1_url_tab, addr_info_t **p_addr_tab, gs_grid_storage_t *gs,
		container_id_t cid, gchar *cname)
{
	addr_info_t *addr;
	gchar str_addr[STRLEN_ADDRINFO];
	GSList *meta1_list = NULL;
	GSList *iter_list = NULL;
	char **m1_tab = NULL;
	addr_info_t *addr_tab = NULL;
	guint i, length;

	// The meta1_list will contain all meta1 addresses.
	// It is passed as the 'exclude' argument to gs_resolve_meta1v2.
	while (NULL != (addr = gs_resolve_meta1v2(gs, cid, cname, 0, &meta1_list, NULL)))
		meta1_list = g_slist_append(meta1_list, addr);
	
	// The result tabs will contain all addresses, plus a NULL trailing element.
	length = g_slist_length(meta1_list) + 1;

	// Result tabs creation.
	if (p_m1_url_tab)
		m1_tab = calloc(length, sizeof(char*));
	if (p_addr_tab)
		addr_tab = calloc(length, sizeof(addr_info_t));
	
	// Fill result tabs
	for (i = 0, iter_list = meta1_list; iter_list; iter_list=iter_list->next, i++) {
		addr_info_to_string(iter_list->data, str_addr, sizeof(str_addr));
		if (p_m1_url_tab)
			m1_tab[i] = strdup(str_addr);
		if (p_addr_tab)
			memcpy(addr_tab + i, iter_list->data, sizeof(addr_info_t));
	}

	// Cleanup
	if (meta1_list) {
		iter_list = meta1_list;
		do {
			g_free(iter_list->data);
		} while (NULL != (iter_list = iter_list->next));
		g_slist_free(meta1_list);
	}

	// Set results
	if (p_m1_url_tab)
		*p_m1_url_tab = m1_tab;
	if (p_addr_tab)
		*p_addr_tab = addr_tab;
}

struct gs_container_location_s *
gs_locate_container(gs_container_t *container, gs_error_t **gserr)
{
	GSList *m2_list;
	gchar str_addr[STRLEN_ADDRINFO];
	struct gs_container_location_s *location;

	location = calloc(1, sizeof(*location));
	if (!location) {
		GSERRORSET(gserr, "Memory allocation failure");
		return NULL;
	}

	struct hc_url_s *url = fill_hcurl_from_container (container);

	/* the names are already known*/
	location->container_name = strdup(C0_NAME(container));
	location->container_hexid = strdup(C0_IDSTR(container));
	
	/*resolve meta0*/
	addr_info_to_string(&(container->info.gs->direct_resolver->meta0), str_addr, sizeof(str_addr));
	location->m0_url = strdup(str_addr);
	
	/*resolve meta2*/
	m2_list = gs_resolve_meta2(container->info.gs, url, NULL);
	if (m2_list) {
		addr_info_t *addr;
		GSList *m2;
		guint i, length;

		length = g_slist_length(m2_list);
		location->m2_url = calloc(length+1, sizeof(char*));
		for (i=0, m2=m2_list; m2 ;m2=m2->next) {
			addr = m2->data;
			if (addr) {
				addr_info_to_string(addr, str_addr, sizeof(str_addr));
				location->m2_url[i++] = strdup(str_addr);
			}
		}

		g_slist_foreach(m2_list, addr_info_gclean, NULL);
		g_slist_free(m2_list);
	}

	_fill_meta1_tabs(&(location->m1_url), NULL, container->info.gs, C0_ID(container), C0_NAME(container));
	hc_url_clean (url);
	return location;
}

static struct gs_container_location_s *
_gs_locate_container_by_cid(gs_grid_storage_t *gs, container_id_t cid, char** out_nsname_on_m1,
	gs_error_t **gserr)
{
	addr_info_t *addr;
	addr_info_t *m1_addr;
	int m1_index = -1;
	gboolean success = FALSE;
	gchar str_addr[STRLEN_ADDRINFO], str_cid[STRLEN_CONTAINERID];;
	struct gs_container_location_s *location;

	location = calloc(1, sizeof(*location));
	if (!location) {
		GSERRORSET(gserr, "Memory allocation failure");
		return NULL;
	}

	container_id_to_string(cid, str_cid, sizeof(str_cid));
	location->container_hexid = strdup(str_cid);
	struct hc_url_s *url = fill_hcurl_from_client (gs);
	hc_url_set (url, HCURL_HEXID, location->container_hexid);

	/*resolve meta0*/
	addr_info_to_string(&(gs->direct_resolver->meta0), str_addr, sizeof(str_addr));
	location->m0_url = strdup(str_addr);

	_fill_meta1_tabs(&(location->m1_url), &m1_addr, gs, cid, NULL);

	/* In this case we ask the META1 for the raw container */
	while (m1_addr[++m1_index].port != 0) { // port 0 -> no more meta1
		struct metacnx_ctx_s cnx_tmp;
		struct meta1_raw_container_s *m1_raw;
		GError *gerror_local;
		gchar *cname = NULL;

		gerror_local = NULL;
		metacnx_clear (&cnx_tmp);
		memcpy(&(cnx_tmp.addr), &(m1_addr[m1_index]), sizeof(addr_info_t));
		m1_raw = meta1_remote_get_container_by_id(&cnx_tmp, url, &gerror_local);
		if (!m1_raw) {
			GSERRORCAUSE(gserr, gerror_local, "Container ID=[%s] not found", str_cid);
			g_clear_error(&gerror_local);
			continue;
		}

		/* copy the ADDRESSES of the possible META2 */
		if (m1_raw->meta2) {
			char *str_addr_copy;
			guint i, length;
			GSList *m2;

			length = g_slist_length(m1_raw->meta2);
			location->m2_url = calloc(length+1, sizeof(char*));
			for (i=0,m2=m1_raw->meta2; m2 ;m2=m2->next) {
				if (NULL != (addr = m2->data) && addr->port != 0) {
					addr_info_to_string(addr, str_addr, sizeof(str_addr));
					if (NULL != (str_addr_copy = strdup(str_addr)))
						location->m2_url[i++] = str_addr_copy;
				}
			}
			g_slist_foreach(m1_raw->meta2, addr_info_gclean, NULL);
			g_slist_free(m1_raw->meta2);
		}

		/* copy the container's name */
		// the answer is formatted NS/CNAME, so we need to skip NS/
		cname = strchr(m1_raw->name, '/');
		if (cname) {
			location->container_name = strdup(cname + 1);
			if (out_nsname_on_m1) {
				cname[0] = '\0';
				*out_nsname_on_m1 = g_strdup(m1_raw->name);    // used if ns is a VNS
			}
		}

		/* that's all, folks! */
		g_free(m1_raw);
		if (gerror_local)
			g_clear_error(&gerror_local);
		success = TRUE;
	}

	if (m1_addr)
		free(m1_addr);

	if (success) {
		gs_error_clear(gserr);
	} else {
		gs_container_location_free(location);
		location = NULL;
	}
	hc_url_clean (url);
	return location;
}

struct gs_container_location_s *
gs_locate_container_by_hexid(gs_grid_storage_t *gs, const char *hexid, gs_error_t **gserr)
{
	return gs_locate_container_by_hexid_v2(gs, hexid, NULL, gserr);
}

struct gs_container_location_s *
gs_locate_container_by_hexid_v2(gs_grid_storage_t *gs, const char *hexid, char** out_nsname_on_m1,
                              gs_error_t **gserr)
{
    if (hexid == NULL) {
        GSERRORSET(gserr, "No container id provided");
        return NULL;
    }

    container_id_t cid;
	container_id_hex2bin(hexid, strlen(hexid), &cid, NULL);
    return _gs_locate_container_by_cid(gs, cid, out_nsname_on_m1, gserr);
}

struct gs_container_location_s *
gs_locate_container_by_name(gs_grid_storage_t *gs, const char *name, gs_error_t **gserr)
{
	if (name == NULL) {
		GSERRORSET(gserr, "No container name provided");
		return NULL;
	}
	
	container_id_t cid;
	meta1_name2hash(cid, gs_get_namespace(gs), gs_get_virtual_namespace(gs), name);
	return _gs_locate_container_by_cid(gs, cid, NULL, gserr);
}

void
gs_container_location_free(struct gs_container_location_s *location)
{
	char ** ptr;
	
	if (!location)
		return;
	if (location->m0_url)
		free(location->m0_url);
	if (location->m1_url) {
		for (ptr=location->m1_url; *ptr; ptr++)
			free(*ptr);
		free(location->m1_url);
	}
	if (location->m2_url) {
		for (ptr=location->m2_url; *ptr; ptr++)
			free(*ptr);
		free(location->m2_url);
	}
	if (location->container_hexid)
		free(location->container_hexid);
	if (location->container_name)
		free(location->container_name);
	free(location);
}

struct hc_url_s *
fill_hcurl_from_client (gs_grid_storage_t *c)
{
	struct hc_url_s *url = hc_url_empty();
	hc_url_set_oldns (url, gs_get_full_namespace(c));
	return url;
}

